// APR STATION ENGINE
// Every listener computes the same schedule from the clock, so everyone tuned to a
// channel hears the same song at the same moment — like real radio, no server needed.
// Each channel plays its whole library in a shuffled order before any song repeats;
// the order reshuffles every cycle.

export const AUDIO_BASE = "https://archive.org/download";
const EPOCH = Date.UTC(2026, 0, 1) / 1000; // the station's "day one"

// (copied from the website's src/station.js so the YouTube stream keeps the exact same clock)
export const SITE = process.env.APR_SITE || "https://alecpennradio.com";
let _data = null;
export function resetStation() { _data = null; }
export async function loadStation() {
  if (_data) return _data;
  const res = await fetch(SITE + "/station.json", { cache: "no-store" });
  const raw = await res.json();
  // a station marked "hidden" is waiting for its songs to finish uploading to archive.org
  const channels = raw.channels.filter((c) => !c.hidden).map((c) => ({
    ...c,
    tracks: c.tracks.map((t, i) => ({ ...t, ia: c.ia, genre: c.name, cover: `${SITE}/covers/${c.slug}/${t.c ?? i}.webp`, key: `${c.slug}/${i}` })),
  }));
  // "FULL STATION": every channel mixed together, special broadcasts included.
  // A song that sits on two stations (e.g. a Revival song that was also a Short) plays once in the mix.
  const seen = new Set(), norm = (t) => t.toLowerCase().replace(/[^a-z0-9]/g, "");
  const mix = [...channels.filter((c) => !c.separate), ...channels.filter((c) => c.separate)].flatMap((c) => c.tracks)
    .filter((t) => { const k = norm(t.t); if (seen.has(k)) return false; seen.add(k); return true; });
  const all = { slug: "all", name: "Full Station", tracks: mix };
  // station jingles: one plays between songs every few songs, at the same moment for every listener
  JINGLES = (raw.jingles || []).map((j, i) => ({ ...j, ia: "jingles", genre: "Station ID", cover: `${SITE}/icons/icon-512.png`, url: `${SITE}/jingles/${j.f}`, key: `jingle/${i}`, jingle: true }));
  _data = { channels, all, total: all.tracks.length };
  return _data;
}

function hashStr(s) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
  return h >>> 0;
}
function rng(seed) { // mulberry32
  return () => {
    seed |= 0; seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function order(channel, cycle) {
  const r = rng(hashStr(channel.slug) + cycle * 7919);
  const idx = channel.tracks.map((_, i) => i);
  for (let i = idx.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [idx[i], idx[j]] = [idx[j], idx[i]]; }
  return idx;
}
let JINGLES = [];
export const jingles = () => JINGLES;
const JINGLE_EVERY = 4;   // a jingle after every 4th song
const cache = new Map();
// which jingle plays in each jingle slot of a cycle (never the same one twice in a row)
function jinglesFor(channel, cycle, slots) {
  const pool = channel.jingles || JINGLES;
  if (!pool.length || !slots) return [];
  const r = rng(hashStr(channel.slug + "/jingle") + cycle * 104729), out = [];
  for (let i = 0; i < slots; i++) { let j = Math.floor(r() * pool.length); if (pool.length > 1 && out.length && j === out[out.length - 1]) j = (j + 1) % pool.length; out.push(j); }
  return out.map((j) => pool[j]);
}
const slotsOf = (channel) => Math.floor(Math.max(0, channel.tracks.length - 1) / JINGLE_EVERY);
function cycleInfo(channel, cycle) {
  const k = channel.slug + ":" + cycle;
  if (!cache.has(k)) {
    let o = order(channel, cycle);
    if (cycle > 0 && o.length > 1) { // never play the same song twice in a row across cycles
      const prev = order(channel, cycle - 1);
      if (o[0] === prev[prev.length - 1]) [o[0], o[1]] = [o[1], o[0]];
    }
    // the running order: songs, with a jingle after every JINGLE_EVERY songs
    const js = jinglesFor(channel, cycle, slotsOf(channel));
    const seq = [];
    let used = 0;
    o.forEach((i, n) => { seq.push(channel.tracks[i]); if ((n + 1) % JINGLE_EVERY === 0 && used < js.length) seq.push(js[used++]); });
    const starts = []; let acc = 0;
    for (const t of seq) { starts.push(acc); acc += t.s; }
    cache.set(k, { o, seq, starts, len: acc });
    if (cache.size > 40) cache.delete(cache.keys().next().value);
  }
  return cache.get(k);
}
const songsLen = (ch) => ch._len || (ch._len = ch.tracks.reduce((a, t) => a + t.s, 0));
// a cycle's length depends on which jingles it got, so walk the cycles from day one (cached per channel)
function locate(channel, t) {
  const pool = channel.jingles || JINGLES;
  if (!pool.length) { const L = songsLen(channel), c = Math.floor(t / L); return { cycle: c, pos: t - c * L }; }
  const st = channel._cyc || (channel._cyc = { starts: [0] });
  const lenOf = (c) => songsLen(channel) + jinglesFor(channel, c, slotsOf(channel)).reduce((a, j) => a + j.s, 0);
  if (t < 0) return { cycle: 0, pos: 0 };
  while (st.starts[st.starts.length - 1] + lenOf(st.starts.length - 1) <= t) st.starts.push(st.starts[st.starts.length - 1] + lenOf(st.starts.length - 1));
  let lo = 0, hi = st.starts.length - 1;
  while (lo < hi) { const mid = (lo + hi + 1) >> 1; if (st.starts[mid] <= t) lo = mid; else hi = mid - 1; }
  return { cycle: lo, pos: t - st.starts[lo] };
}

// What's on air on this channel at time `now` (seconds)?
export function onAir(channel, now = Date.now() / 1000) {
  const { cycle, pos } = locate(channel, now - EPOCH);
  const { seq, starts } = cycleInfo(channel, cycle);
  let lo = 0, hi = seq.length - 1;
  while (lo < hi) { const mid = (lo + hi + 1) >> 1; if (starts[mid] <= pos) lo = mid; else hi = mid - 1; }
  const track = seq[lo];
  const offset = pos - starts[lo];
  const next = lo + 1 < seq.length ? seq[lo + 1] : cycleInfo(channel, cycle + 1).seq[0];
  return { track, offset, remaining: track.s - offset, next };
}

export function audioUrl(track) {
  if (track.url) return track.url;   // jingles live on the site itself
  return `${AUDIO_BASE}/${track.ia}/${encodeURIComponent(track.f)}`;
}

// Turn the per-song loudness correction (dB) into a volume multiplier.
// Most songs play at full volume; only the extra-loud ones are eased down to match.
// (A web page can't push a song above its natural level, so we never turn the normal ones down.)
export function gainMul(track) {
  return Math.min(1, Math.pow(10, ((track.g || 0) + 1.5) / 20));
}

// Everything scheduled on this channel from `now` for the next `seconds` (for saving ahead).
export function upcoming(channel, now, seconds) {
  const out = []; let t = now; const end = now + seconds; let guard = 0;
  while (t < end && guard++ < 3000) {
    const info = onAir(channel, t);
    if (!info.track.jingle) out.push({ track: info.track, start: t - info.offset });   // jingles aren't saved for offline
    t += info.remaining + 0.01;
  }
  return out;
}

// How long the radio can keep playing from songs already on the phone, starting now (seconds).
export function offlineCoverage(channel, has, now = Date.now() / 1000, limit = 7 * 86400) {
  let t = now, guard = 0;
  while (t < now + limit && guard++ < 20000) {
    const info = onAir(channel, t);
    if (!info.track.jingle && !has(info.track)) return t - now;
    t += info.remaining + 0.01;
  }
  return limit;
}
