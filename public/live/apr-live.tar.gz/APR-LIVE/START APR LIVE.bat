@echo off
title Alec Penn Radio - LIVE on YouTube
cd /d "%~dp0"
echo.
echo   ALEC PENN RADIO  -^>  YOUTUBE LIVE
echo   ==================================
where node >nul 2>nul || (
  echo   Installing Node.js ^(first time only^)...
  winget install -e --id OpenJS.NodeJS.LTS --accept-source-agreements --accept-package-agreements
  echo   Node installed. Close this window and double-click START APR LIVE.bat again.
  pause & exit /b
)
where ffmpeg >nul 2>nul || (
  echo   Installing ffmpeg ^(first time only^)...
  winget install -e --id Gyan.FFmpeg --accept-source-agreements --accept-package-agreements
  echo   ffmpeg installed. Close this window and double-click START APR LIVE.bat again.
  pause & exit /b
)
:loop
node live.mjs
echo.
echo   The broadcaster stopped. Restarting in 10 seconds... ^(close this window to stop for real^)
timeout /t 10 >nul
goto loop
