@echo off
title Alec Penn Radio - test
cd /d "%~dp0"
echo   Making a 60-second test video (test-stream.flv) without going live...
node live.mjs --test 60
echo   Done. Open test-stream.flv to see what YouTube viewers will see.
pause
