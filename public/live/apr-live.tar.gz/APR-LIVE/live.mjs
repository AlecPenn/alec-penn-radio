// ALEC PENN RADIO — LIVE ON YOUTUBE
// Streams the Full Station to YouTube 24/7, in sync with alecpennradio.com:
// it asks the website's own clock what's on air right now and plays that exact song from that exact second.
//
// Start it with "START APR LIVE.bat". Your stream key lives in youtube-key.txt (never share it).
// Test without YouTube:  node live.mjs --test 60   (writes test-stream.flv, 60 seconds)

import { spawn, spawnSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { loadStation, resetStation, onAir, audioUrl, SITE } from "./station.mjs";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const A = (f) => path.join(HERE, "assets", f);
const WORK = path.join(HERE, "work"); fs.mkdirSync(WORK, { recursive: true });
const FF = process.env.APR_FFMPEG || "ffmpeg";
const args = process.argv.slice(2);
const TEST = args.includes("--test") ? Number(args[args.indexOf("--test") + 1] || 60) : 0;
// APR_SIZE=720 streams 1280x720 (half the upload speed and CPU of 1080p)
const SMALL = String(process.env.APR_SIZE || "1080") === "720";
const VB = SMALL ? "2500k" : "4500k", VBUF = SMALL ? "5000k" : "9000k";
const RATE = 44100, CH = 2, BPS = RATE * CH * 2;            // raw audio: 44.1 kHz, stereo, 16-bit
const log = (...m) => console.log(new Date().toLocaleTimeString(), ...m);

// ---------- stream key ----------
function streamUrl() {
  if (TEST) return null;
  const f = path.join(HERE, "youtube-key.txt");
  const key = fs.existsSync(f) ? fs.readFileSync(f, "utf8").split(/\r?\n/).map((l) => l.trim()).find((l) => l && !l.startsWith("#") && !/PASTE/i.test(l)) : "";
  if (!key) { console.log("\n  Your YouTube stream key isn't in youtube-key.txt yet. Open it and follow the steps at the top.\n"); process.exit(1); }
  return key.startsWith("rtmp") ? key : `rtmp://a.rtmp.youtube.com/live2/${key}`;
}

// ---------- what's on screen ----------
const esc = (s) => String(s);   // text is drawn exactly as written (expansion=none)
function wrap(t, n) { const w = String(t).split(" "), out = [""]; for (const x of w) { if ((out[out.length - 1] + " " + x).trim().length > n && out[out.length - 1]) out.push(x); else out[out.length - 1] = (out[out.length - 1] + " " + x).trim(); } return out.slice(0, 3).join("\n"); }
function swap(file, data) { const tmp = file + ".new"; fs.writeFileSync(tmp, data); for (let i = 0; i < 20; i++) { try { fs.renameSync(tmp, file); return; } catch (e) { spawnSync(process.execPath, ["-e", "setTimeout(()=>{},25)"]); } } }
async function show(info) {
  const t = info.track;
  swap(path.join(WORK, "title.txt"), esc(t.jingle ? "STATION ID" : wrap(t.t.toUpperCase(), 22)));
  swap(path.join(WORK, "station.txt"), esc(t.jingle ? t.t : `${t.genre}  ·  free at edensgate.art`));
  swap(path.join(WORK, "next.txt"), esc(info.next?.t || ""));
  try {   // cover art from the website, converted to a plain image ffmpeg can re-read every second
    const r = await fetch(t.cover); if (!r.ok) throw new Error(r.status);
    const src = path.join(WORK, "cover-src"); fs.writeFileSync(src, Buffer.from(await r.arrayBuffer()));
    const out = path.join(WORK, "cover.new.png");
    spawnSync(FF, ["-v", "error", "-y", "-i", src, "-vf", "scale=620:620:flags=lanczos", out]);
    if (fs.existsSync(out)) for (let i = 0; i < 20; i++) { try { fs.renameSync(out, path.join(WORK, "cover.png")); break; } catch (e) { spawnSync(process.execPath, ["-e", "setTimeout(()=>{},25)"]); } }
  } catch (e) { log("cover", e.message); }
}

// ---------- the encoder: raw audio in, finished 1080p stream out ----------
function pickVideoEncoder() {
  if (process.env.APR_ENCODER) return process.env.APR_ENCODER;
  const r = spawnSync(FF, ["-hide_banner", "-encoders"], { encoding: "utf8" });
  if (/h264_nvenc/.test(r.stdout || "")) {   // use the graphics card if it really works
    const t = spawnSync(FF, ["-v", "error", "-f", "lavfi", "-i", "color=s=256x256:d=0.2", "-c:v", "h264_nvenc", "-f", "null", "-"]);
    if (t.status === 0) return "h264_nvenc";
  }
  return "libx264";
}
let enc = null;
function startEncoder() {
  const url = streamUrl(), venc = pickVideoEncoder();
  const font = (f) => A(f).replace(/\\/g, "/").replace(/:/g, "\\:");
  const tf = (f) => path.join(WORK, f).replace(/\\/g, "/").replace(/:/g, "\\:");
  const filter = [
    "[0:a]asplit=2[aout][av]",
    "[av]showfreqs=s=81x150:mode=bar:ascale=cbrt:fscale=log:win_size=2048:averaging=4:colors=0xC2A24D|0xC2A24D,scale=1620:150:flags=neighbor,drawgrid=w=20:h=1000:t=6:c=black,format=rgba,colorkey=0x000000:0.1:0.0[viz]",
    "[2:v]scale=620:620,format=rgba[cov]",
    "[1:v][cov]overlay=150:170[b1]",
    "[b1][viz]overlay=150:850[b2]",
    `[b2]drawtext=fontfile='${font("BebasNeue.ttf")}':textfile='${tf("title.txt")}':reload=1:expansion=none:fontcolor=0xF4F1EC:fontsize=104:line_spacing=-28:x=850:y=300,` +
    `drawtext=fontfile='${font("JetBrainsMono.ttf")}':textfile='${tf("station.txt")}':reload=1:expansion=none:fontcolor=0x5E9E9C:fontsize=30:x=850:y=575,` +
    `drawtext=fontfile='${font("JetBrainsMono.ttf")}':textfile='${tf("next.txt")}':reload=1:expansion=none:fontcolor=0xD4B96A:fontsize=34:x=850:y=685,` +
    (SMALL ? "scale=1280:720:flags=bicubic," : "") + "format=yuv420p[vout]",
  ].join(";");
  const v = venc === "h264_nvenc"
    ? ["-c:v", "h264_nvenc", "-preset", "p4", "-b:v", VB, "-maxrate", VB, "-bufsize", VBUF]
    : ["-c:v", "libx264", "-preset", "veryfast", "-tune", "stillimage", "-b:v", VB, "-maxrate", VB, "-bufsize", VBUF];
  const out = url ? ["-f", "flv", url] : ["-t", String(TEST), "-y", path.join(HERE, "test-stream.flv")];
  const a = ["-hide_banner", "-loglevel", "warning",
    "-re", "-thread_queue_size", "1024", "-f", "s16le", "-ar", String(RATE), "-ac", String(CH), "-i", "pipe:0",
    "-thread_queue_size", "64", "-loop", "1", "-framerate", "30", "-i", A("frame.png"),
    "-thread_queue_size", "64", "-f", "image2", "-loop", "1", "-framerate", "1", "-i", path.join(WORK, "cover.png"),
    "-filter_complex", filter, "-map", "[vout]", "-map", "[aout]",
    ...v, "-r", "30", "-g", "60", "-pix_fmt", "yuv420p",
    "-c:a", "aac", "-b:a", "160k", "-ar", String(RATE), ...out];
  log(`going live (${venc}, ${SMALL ? "720p" : "1080p"})${url ? "" : " — TEST, writing test-stream.flv"}`);
  enc = spawn(FF, a, { stdio: ["pipe", "inherit", "inherit"] });
  enc.stdin.on("error", () => {});
  enc.on("exit", (code) => {
    enc = null; if (TEST) { log("test finished"); process.exit(0); }
    log(`stream stopped (${code}). Reconnecting in 5 seconds...`); setTimeout(startEncoder, 5000);
  });
}
const write = (buf) => new Promise((res) => { if (!enc) return setTimeout(res, 200); if (enc.stdin.write(buf)) res(); else enc.stdin.once("drain", res); });
const silence = (sec) => write(Buffer.alloc(Math.floor(BPS * sec / 4) * 4));

// ---------- fetch songs one ahead, so there's never a gap between them ----------
const cache = new Map();
function fetchSong(track) {
  const url = process.env.APR_FAKE_AUDIO && !track.jingle ? process.env.APR_FAKE_AUDIO + "#" + track.t : audioUrl(track);   // (testing only)
  if (!cache.has(url)) cache.set(url, (async () => {
    const f = path.join(WORK, `song-${Math.random().toString(36).slice(2)}.mp3`);
    for (let i = 0; i < 3; i++) {
      try { const r = await fetch(url.split("#")[0]); if (!r.ok) throw new Error(r.status); fs.writeFileSync(f, Buffer.from(await r.arrayBuffer())); return f; }
      catch (e) { log("download retry", track.t, e.message); await new Promise((r) => setTimeout(r, 3000)); }
    }
    return null;
  })());
  return cache.get(url);
}
function forget(track) { const url = process.env.APR_FAKE_AUDIO && !track.jingle ? process.env.APR_FAKE_AUDIO + "#" + track.t : audioUrl(track); const p = cache.get(url); cache.delete(url); p?.then((f) => f && fs.rm(f, { force: true }, () => {})); }

// ---------- play: always whatever alecpennradio.com is playing right now ----------
const gainMul = (t) => Math.min(1, Math.pow(10, ((t.g || 0) + 1.5) / 20));   // same loudness rule as the website
async function playOne(station) {
  const info = onAir(station.all);
  const file = await fetchSong(info.track);
  fetchSong(info.next);                                       // get the next song ready while this one plays
  const now = onAir(station.all);                             // the download took a moment: re-check the clock
  if (now.track !== info.track || !file) { if (!file) { forget(info.track); await silence(1); } return; }
  if (now.remaining < 1.5) { await silence(now.remaining); return; }       // only the tail end is left: let the next song start clean
  await show(now);
  log(`▶ ${now.track.t}  (${now.track.genre})  from ${Math.round(now.offset)}s`);
  const from = process.env.APR_FAKE_AUDIO && !now.track.jingle ? 0 : Math.max(0, now.offset);   // (test files are short)
  const dec = spawn(FF, ["-v", "error", "-ss", String(from), "-i", file, "-f", "s16le", "-ar", String(RATE), "-ac", String(CH), "-af", `volume=${gainMul(now.track).toFixed(3)}`, "pipe:1"], { stdio: ["ignore", "pipe", "inherit"] });
  let sent = 0;
  for await (const chunk of dec.stdout) { sent += chunk.length; await write(chunk); }
  forget(now.track);
  if (sent < BPS * 0.5) { log("no sound from", now.track.t, "- skipping it"); await silence(Math.min(5, Math.max(1, now.remaining))); }   // a broken file never makes it loop
}

async function main() {
  console.log("\n  ALEC PENN RADIO  ->  YOUTUBE LIVE\n  " + "=".repeat(34));
  if (spawnSync(FF, ["-version"]).status !== 0) { console.log("  ffmpeg isn't installed. Run START APR LIVE.bat (not this file)."); process.exit(1); }
  let station = await loadStation();
  setInterval(() => { resetStation(); loadStation().then((s) => { station = s; }).catch(() => {}); }, 60 * 60 * 1000);   // pick up new songs every hour
  fs.writeFileSync(path.join(WORK, "title.txt"), "TUNING IN"); fs.writeFileSync(path.join(WORK, "station.txt"), ""); fs.writeFileSync(path.join(WORK, "next.txt"), "");
  spawnSync(FF, ["-v", "error", "-y", "-i", A("frame.png"), "-vf", "crop=620:620:150:170", path.join(WORK, "cover.png")]);
  startEncoder();
  await silence(0.5);
  for (;;) { try { await playOne(station); } catch (e) { log("hiccup:", e.message); await silence(2); } }
}
main();
