// ALEC PENN RADIO — LIVE ON YOUTUBE
// Streams the Full Station to YouTube 24/7, in sync with alecpennradio.com:
// it asks the website's own clock what's on air right now and plays that exact song from that exact second.
//
// Start it with "START APR LIVE.bat". Your stream key lives in youtube-key.txt (never share it).
// Test without YouTube:  node live.mjs --test 60   (writes test-stream.flv, 60 seconds)

import { spawn, spawnSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { loadStation, resetStation, onAir, audioUrl, jingles, SITE } from "./station.mjs";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const A = (f) => path.join(HERE, "assets", f);
const WORK = path.join(HERE, "work"); fs.mkdirSync(WORK, { recursive: true });
const FF = process.env.APR_FFMPEG || "ffmpeg";
const args = process.argv.slice(2);
const TEST = args.includes("--test") ? Number(args[args.indexOf("--test") + 1] || 60) : 0;
// APR_SIZE=720 streams 1280x720 (half the upload speed and CPU of 1080p)
const SMALL = String(process.env.APR_SIZE || "1080") === "720";
const VB = SMALL ? "2500k" : "4500k", VBUF = SMALL ? "5000k" : "9000k";
const RATE = 44100, CH = 2, BPS = RATE * CH * 2;            // raw audio: 44.1 kHz, stereo, 16-bit
const log = (...m) => console.log(new Date().toLocaleTimeString(), ...m);

// ---------- stream key ----------
function streamUrl() {
  if (TEST) return null;
  const f = path.join(HERE, "youtube-key.txt");
  const key = fs.existsSync(f) ? fs.readFileSync(f, "utf8").split(/\r?\n/).map((l) => l.trim()).find((l) => l && !l.startsWith("#") && !/PASTE/i.test(l)) : "";
  if (!key) { console.log("\n  Your YouTube stream key isn't in youtube-key.txt yet. Open it and follow the steps at the top.\n"); process.exit(1); }
  return key.startsWith("rtmp") ? key : `rtmp://a.rtmp.youtube.com/live2/${key}`;
}

// ---------- what's on screen ----------
const esc = (s) => String(s);   // text is drawn exactly as written (expansion=none)
function wrap(t, n) { const w = String(t).split(" "), out = [""]; for (const x of w) { if ((out[out.length - 1] + " " + x).trim().length > n && out[out.length - 1]) out.push(x); else out[out.length - 1] = (out[out.length - 1] + " " + x).trim(); } return out.slice(0, 3).join("\n"); }
const nap = (ms) => Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms);
function swap(file, data) { const tmp = file + ".new"; fs.writeFileSync(tmp, data); for (let i = 0; i < 20; i++) { try { fs.renameSync(tmp, file); return; } catch (e) { nap(25); } } }
async function show(info) {
  const t = info.track;
  swap(path.join(WORK, "title.txt"), esc(t.jingle ? "STATION ID" : wrap(t.t.toUpperCase(), 22)));
  swap(path.join(WORK, "station.txt"), esc(t.jingle ? t.t : `${t.genre}  ·  free at edensgate.art`));
  swap(path.join(WORK, "next.txt"), esc(info.next?.t || ""));
  try {   // cover art from the website, converted to a plain image ffmpeg can re-read every second
    const r = await fetch(t.cover); if (!r.ok) throw new Error(r.status);
    const src = path.join(WORK, "cover-src"); fs.writeFileSync(src, Buffer.from(await r.arrayBuffer()));
    const out = path.join(WORK, "cover.new.png");
    await new Promise((res) => spawn(FF, ["-v", "error", "-y", "-i", src, "-vf", "scale=620:620:flags=lanczos", out]).on("exit", res).on("error", res));   // in the background: the music never waits on it
    if (fs.existsSync(out)) for (let i = 0; i < 20; i++) { try { fs.renameSync(out, path.join(WORK, "cover.png")); break; } catch (e) { await new Promise((r) => setTimeout(r, 25)); } }
  } catch (e) { log("cover", e.message); }
}

// ---------- the encoder: raw audio in, finished 1080p stream out ----------
function pickVideoEncoder() {
  if (process.env.APR_ENCODER) return process.env.APR_ENCODER;
  const r = spawnSync(FF, ["-hide_banner", "-encoders"], { encoding: "utf8" });
  if (/h264_nvenc/.test(r.stdout || "")) {   // use the graphics card if it really works
    const t = spawnSync(FF, ["-v", "error", "-f", "lavfi", "-i", "color=s=256x256:d=0.2", "-c:v", "h264_nvenc", "-f", "null", "-"]);
    if (t.status === 0) return "h264_nvenc";
  }
  return "libx264";
}
let enc = null;
function startEncoder() {
  const url = streamUrl(), venc = pickVideoEncoder();
  const font = (f) => A(f).replace(/\\/g, "/").replace(/:/g, "\\:");
  const tf = (f) => path.join(WORK, f).replace(/\\/g, "/").replace(/:/g, "\\:");
  // The picture is built straight at the output size (no shrinking every frame), the background is loaded once,
  // and the song text is re-read once a second: light enough for a small server or a busy PC.
  const k = SMALL ? 2 / 3 : 1, W = SMALL ? 1280 : 1920, H = SMALL ? 720 : 1080, n = (v) => Math.round(v * k);
  const filter = [
    "[0:a]asplit=2[aout][av]",
    `[av]showfreqs=s=81x${n(150)}:mode=bar:ascale=cbrt:fscale=log:win_size=2048:averaging=4:colors=0xC2A24D|0xC2A24D,scale=${n(1620)}:${n(150)}:flags=neighbor,drawgrid=w=${(20 * k).toFixed(3)}:h=4000:t=${Math.max(3, n(6))}:c=black,format=rgba,colorkey=0x000000:0.1:0.0[viz]`,
    `[1:v]scale=${W}:${H},loop=loop=-1:size=1:start=0,setpts=N/(30*TB),format=yuv420p[bg]`,
    `[2:v]scale=${n(620)}:${n(620)}[cov]`,
    `[bg][cov]overlay=${n(150)}:${n(170)}:format=yuv420[b1]`,
    `[b1][viz]overlay=${n(150)}:${n(850)}:format=yuv420[b2]`,
    `[b2]drawtext=fontfile='${font("BebasNeue.ttf")}':textfile='${tf("title.txt")}':reload=30:expansion=none:fontcolor=0xF4F1EC:fontsize=${n(104)}:line_spacing=${n(-28)}:x=${n(850)}:y=${n(300)},` +
    `drawtext=fontfile='${font("JetBrainsMono.ttf")}':textfile='${tf("station.txt")}':reload=30:expansion=none:fontcolor=0x5E9E9C:fontsize=${n(30)}:x=${n(850)}:y=${n(575)},` +
    `drawtext=fontfile='${font("JetBrainsMono.ttf")}':textfile='${tf("next.txt")}':reload=30:expansion=none:fontcolor=0xD4B96A:fontsize=${n(34)}:x=${n(850)}:y=${n(685)},` +
    "format=yuv420p[vout]",
  ].join(";");
  const v = venc === "h264_nvenc"
    ? ["-c:v", "h264_nvenc", "-preset", "p4", "-b:v", VB, "-maxrate", VB, "-bufsize", VBUF]
    : ["-c:v", "libx264", "-preset", "veryfast", "-tune", "stillimage", "-b:v", VB, "-maxrate", VB, "-bufsize", VBUF];
  const out = url ? ["-f", "flv", url] : ["-t", String(TEST), "-y", path.join(HERE, "test-stream.flv")];
  const a = ["-hide_banner", "-loglevel", "warning",
    "-re", "-thread_queue_size", "1024", "-f", "s16le", "-ar", String(RATE), "-ac", String(CH), "-i", "pipe:0",
    "-thread_queue_size", "64", "-i", A("frame.png"),
    "-thread_queue_size", "64", "-f", "image2", "-loop", "1", "-framerate", "1", "-i", path.join(WORK, "cover.png"),
    "-filter_complex", filter, "-map", "[vout]", "-map", "[aout]",
    ...v, "-r", "30", "-g", "60", "-pix_fmt", "yuv420p",
    "-c:a", "aac", "-b:a", "160k", "-ar", String(RATE), ...out];
  log(`going live (${venc}, ${SMALL ? "720p" : "1080p"})${url ? "" : " — TEST, writing test-stream.flv"}`);
  enc = spawn(FF, a, { stdio: ["pipe", "inherit", "inherit"] });
  enc.stdin.on("error", () => {});
  enc.on("exit", (code) => {
    enc = null; if (pendingDrain) { const f = pendingDrain; pendingDrain = null; f(); }
    if (TEST) { log("test finished"); process.exit(0); }
    log(`stream stopped (${code}). Reconnecting in 2 seconds...`); setTimeout(startEncoder, 2000);
  });
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let pendingDrain = null;
const write = (buf) => new Promise((res) => {
  if (!enc) return setTimeout(res, 100);
  if (enc.stdin.write(buf)) return res();
  pendingDrain = res;
  enc.stdin.once("drain", () => { if (pendingDrain === res) pendingDrain = null; res(); });
});

// ---------- the sound pump: YouTube is fed every 100 ms, always ----------
// Songs are decoded into a queue a few seconds ahead. If the queue is ever empty (a slow download, a song
// change), the pump sends silence instead of nothing, so YouTube never sees the stream go quiet and drop it.
const STEP = Math.floor(BPS * 0.1 / 4) * 4, HUSH = Buffer.alloc(STEP);
const q = []; let qBytes = 0, feeding = false;
function take() {
  if (qBytes < STEP && (feeding || !qBytes)) return null;
  const n = Math.min(STEP, qBytes), parts = []; let got = 0;
  while (got < n) { const b = q[0], need = n - got; if (b.length <= need) { parts.push(b); got += b.length; q.shift(); } else { parts.push(b.subarray(0, need)); q[0] = b.subarray(need); got = n; } }
  qBytes -= n;
  const out = Buffer.concat(parts, n);
  return n === STEP ? out : Buffer.concat([out, Buffer.alloc(STEP - n)]);   // end of a song: pad the last scrap
}
async function pump() { for (;;) { if (!enc) { await sleep(100); continue; } await write(take() || HUSH); } }
const queued = () => qBytes / BPS;

// ---------- downloads: two songs ahead, in the background, with time limits ----------
const cache = new Map(), played = [];
const urlOf = (t) => process.env.APR_FAKE_AUDIO && !t.jingle ? process.env.APR_FAKE_AUDIO + "#" + t.t : audioUrl(t);   // (testing only)
function fetchSong(track) {
  const url = urlOf(track);
  if (!cache.has(url)) cache.set(url, (async () => {
    const f = path.join(WORK, `song-${Math.random().toString(36).slice(2)}.mp3`);
    for (let i = 0; i < 3; i++) {
      try {
        const r = await fetch(url.split("#")[0], { signal: AbortSignal.timeout(90000) });
        if (!r.ok) throw new Error(r.status);
        fs.writeFileSync(f, Buffer.from(await r.arrayBuffer())); return f;
      } catch (e) { log("download retry", track.t, e.message); await sleep(2500); }
    }
    cache.delete(url); return null;   // give up for now; a later attempt starts fresh
  })());
  return cache.get(url);
}
function remember(track, file) {   // keep the last 25 songs on disk as backups for when archive.org hiccups
  played.push({ track, file, url: urlOf(track) });
  while (played.length > 25) { const old = played.shift(); cache.delete(old.url); fs.rm(old.file, { force: true }, () => {}); }
}
// clear out songs left over from an earlier run
for (const f of fs.readdirSync(WORK)) if (/^song-.*\.mp3$/.test(f)) fs.rm(path.join(WORK, f), { force: true }, () => {});

// ---------- the player: always whatever alecpennradio.com is playing at the moment it will be heard ----------
const gainMul = (t) => Math.min(1, Math.pow(10, ((t.g || 0) + 1.5) / 20));   // same loudness rule as the website
let station = null, started = false;
async function decode(track, file, from) {
  const dec = spawn(FF, ["-v", "error", "-ss", String(from), "-i", file, "-f", "s16le", "-ar", String(RATE), "-ac", String(CH), "-af", `volume=${gainMul(track).toFixed(3)}`, "pipe:1"], { stdio: ["ignore", "pipe", "inherit"] });
  feeding = true; let sent = 0;
  try {
    for await (const chunk of dec.stdout) {
      q.push(chunk); qBytes += chunk.length; sent += chunk.length;
      while (qBytes > BPS * 6) await sleep(100);          // stay ~6 seconds ahead, no more
    }
  } finally { feeding = false; }
  return sent;
}
async function queueNext() {
  while (queued() > 3) await sleep(100);                  // the next song is lined up 3 seconds before it's needed
  const heardAt = () => Date.now() / 1000 + queued();     // when what we add now will actually be heard
  const info = onAir(station.all, heardAt());
  const file = await fetchSong(info.track);
  const after = onAir(station.all, heardAt() + info.remaining + 1);   // get the next two songs ready meanwhile
  fetchSong(after.track); if (after.next) fetchSong(after.next);
  const now = onAir(station.all, heardAt());
  if (now.track !== info.track && file) { return; }       // the clock moved on while downloading: line up the new song
  let track = now.track, f = file, from;
  if (!f) {                                               // archive.org didn't deliver: play something we already have
    const pool = played.filter((p) => fs.existsSync(p.file));
    let pick = pool.length ? pool[Math.floor(Math.random() * pool.length)] : null;
    if (!pick && jingles().length) {                      // nothing saved yet: a station jingle (it comes from the website, not archive.org)
      const j = jingles()[Math.floor(Math.random() * jingles().length)], jf = await fetchSong(j);
      if (jf) pick = { track: j, file: jf };
    }
    if (!pick) { log("waiting for archive.org..."); await sleep(3000); return; }   // the pump keeps the stream alive meanwhile
    log(`archive.org didn't send "${now.track.t}" in time: playing "${pick.track.t}" instead`);
    track = pick.track; f = pick.file; from = 0;
  } else {
    if (now.remaining < 1.5) { while (queued() > 0.2) await sleep(50); await sleep(now.remaining * 1000); return; }
    // Behind by only a little (the normal case): play from the top so no intro gets clipped.
    // Joining fresh, or far behind after an outage: jump in mid-song to stay with the website.
    from = started && now.offset < 20 ? 0 : Math.max(0, now.offset);
    if (process.env.APR_FAKE_AUDIO && !track.jingle) from = 0;
  }
  started = true;
  const lead = queued();
  setTimeout(() => { show({ ...now, track }).catch(() => {}); log(`▶ ${track.t}  (${track.genre})  from ${Math.round(from)}s`); }, lead * 1000);
  const sent = await decode(track, f, from);
  if (f === file) remember(track, f);
  if (sent < BPS * 0.5) { log("no sound from", track.t, "- skipping it"); await sleep(2000); }
}

async function main() {
  console.log("\n  ALEC PENN RADIO  ->  YOUTUBE LIVE\n  " + "=".repeat(34));
  if (spawnSync(FF, ["-version"]).status !== 0) { console.log("  ffmpeg isn't installed. Run START APR LIVE.bat (not this file)."); process.exit(1); }
  for (;;) { try { station = await loadStation(); break; } catch (e) { log("can't reach alecpennradio.com yet, retrying...", e.message); await sleep(10000); } }
  setInterval(() => { resetStation(); loadStation().then((s) => { station = s; }).catch(() => {}); }, 60 * 60 * 1000);   // pick up new songs every hour
  fs.writeFileSync(path.join(WORK, "title.txt"), "TUNING IN"); fs.writeFileSync(path.join(WORK, "station.txt"), ""); fs.writeFileSync(path.join(WORK, "next.txt"), "");
  spawnSync(FF, ["-v", "error", "-y", "-i", A("frame.png"), "-vf", "crop=620:620:150:170", path.join(WORK, "cover.png")]);
  startEncoder();
  pump();
  for (;;) { try { await queueNext(); } catch (e) { log("hiccup:", e.message); await sleep(1000); } }
}
main();
